// Use browser instead of chrome for Firefox compatibility
const browserAPI = typeof browser !== "undefined" ? browser : chrome;

// Rule 1
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "referer");
      headers.push({ name: "Referer", value: "https://www.wps.irctc.co.in/" });
      return { requestHeaders: headers };
    },
    { urls: ["https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA="] },
    ["blocking", "requestHeaders"]
  );
});

// Rule 2
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "origin" && header.name.toLowerCase() !== "referer");
      headers.push({ name: "Origin", value: "https://www.irctcipay.com" });
      headers.push({ name: "Referer", value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp" });
      return { requestHeaders: headers };
    },
    { urls: ["https://www.irctcipay.com/pgui/jsp/otmPay"] },
    ["blocking", "requestHeaders"]
  );
});

// Rule 3 (Note: You had two identical Rule 3s; I’ll assume one was meant to be Rule 4 or unique)
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "connection");
      headers.push({ name: "Connection", value: "close" });
      return { requestHeaders: headers };
    },
    { urls: ["https://www.irctc.co.in/*"] },
    ["blocking", "requestHeaders"]
  );
});


// Rule 2
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "origin" && header.name.toLowerCase() !== "referer");
      headers.push({ name: "Origin", value: "https://secure.paytmpayments.com" });
      headers.push({ name: "Referer", value: "https://secure.paytmpayments.com/" });
      return { requestHeaders: headers };
    },
    { urls: ["https://secure.paytmpayments.com"] },
    ["blocking", "requestHeaders"]
  );
});


// Rule 3 (Note: You had two identical Rule 3s; I’ll assume one was meant to be Rule 4 or unique)
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "connection");
      headers.push({ name: "Connection", value: "close" });
      return { requestHeaders: headers };
    },
    { urls: ["https://secure.paytmpayments.com/*"] },
    ["blocking", "requestHeaders"]
  );
});


// Rule 2
browserAPI.runtime.onInstalled.addListener(() => {
  browserAPI.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let headers = details.requestHeaders;
      headers = headers.filter(header => header.name.toLowerCase() !== "origin" && header.name.toLowerCase() !== "referer");
      headers.push({ name: "Origin", value: "https://www.irctc.co.in" });
      headers.push({ name: "Referer", value: "https://www.irctc.co.in/nget-search" });
      return { requestHeaders: headers };
    },
    { urls: ["https://www.irctc.co.in/*"] },
    ["blocking", "requestHeaders"]
  );
});

// Handle messages from other parts of the extension
browserAPI.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTrainData") {
    fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
      method: "GET",
      headers: {
        "Connection": "close",
        "sec-ch-ua-platform": "\"macOS\"",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "DNT": "1",
        "sec-ch-ua-mobile": "?0",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9"
      }
    })
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      return response.json();
    })
    .then(data => {
      const processedData = data.map(item => {
        const parts = item.split(" - ");
        return {
          number: parts[0].trim(),
          name: parts[1] ? parts[1].trim() : ""
        };
      });
      sendResponse({ success: true, data: processedData });
    })
    .catch(error => {
      console.error("Error fetching train data:", error);
      sendResponse({ success: false, error: error.toString() });
    });
    return true; // Indicates asynchronous response
  }
});

// Open index.html when the extension icon is clicked
browserAPI.browserAction.onClicked.addListener(() => {
  browserAPI.tabs.create({ url: browserAPI.runtime.getURL("index.html") });
});