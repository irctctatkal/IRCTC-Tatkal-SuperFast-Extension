// Runs when the extension is installed or updated
chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1, 2, 3, 4, 5, 6, 7, 8, 9], // Clear any existing rules with these IDs
    addRules: [
      {
        id: 1,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Referer", operation: "set", value: "https://www.wps.irctc.co.in/" }
          ]
        },
        condition: {
          urlFilter: "https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA=",
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 2,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://www.irctcipay.com" },
            { header: "Referer", operation: "set", value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp" }
          ]
        },
        condition: {
          urlFilter: "https://www.irctcipay.com",
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 3,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://www.irctc.co.in" },
            { header: "Referer", operation: "set", value: "https://www.irctc.co.in/nget/train-search" }
          ]
        },
        condition: {
          urlFilter: "https://www.irctc.co.in",
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 4,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Connection", operation: "set", value: "close" }
          ]
        },
        condition: {
          urlFilter: "https://www.irctc.co.in", // Applies to all URLs
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 5,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Connection", operation: "set", value: "close" }
          ]
        },
        condition: {
          urlFilter: "https://www.wps.irctc.co.in", // Applies to all URLs
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 6,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Connection", operation: "set", value: "close" }
          ]
        },
        condition: {
          urlFilter: "https://www.irctcipay.com", // Applies to all URLs
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },

      {
        id: 7,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://secure.paytmpayments.com" },
            { header: "Referer", operation: "set", value: "https://secure.paytmpayments.com/" }
          ]
        },
        condition: {
          urlFilter: "https://secure.paytmpayments.com/theia/api/v1/processTransaction",
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },

      {
        id: 8,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Connection", operation: "set", value: "close" }
          ]
        },
        condition: {
          urlFilter: "https://secure.paytmpayments.com", // Applies to all URLs
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      },
      {
        id: 9,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "Origin", operation: "set", value: "https://api.apitruecaptcha.org" },
            { header: "Referer", operation: "set", value: "https://api.apitruecaptcha.org" }
          ]
        },
        condition: {
          urlFilter: "https://api.apitruecaptcha.org",
          resourceTypes: ["main_frame", "xmlhttprequest"]
        }
      }
    ]
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("Error updating rules:", chrome.runtime.lastError.message);
    } else {
      console.log("Dynamic rules updated successfully");
    }
  });
});


// Handle messages from other parts of the extension (e.g., content scripts or popup)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTrainData") {
    fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
      method: "GET",
      headers: {
        "Connection": "close", // Changed to "close" to align with your earlier request
        "sec-ch-ua-platform": "\"macOS\"",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "DNT": "1",
        "sec-ch-ua-mobile": "?0",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9"
      }
    })
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      return response.json();
    })
    .then(data => {
      // Process the data to split each item into number and name
      const processedData = data.map(item => {
        const parts = item.split(" - ");
        return {
          number: parts[0].trim(),
          name: parts[1] ? parts[1].trim() : ""
        };
      });
      sendResponse({ success: true, data: processedData });
    })
    .catch(error => {
      console.error("Error fetching train data:", error);
      sendResponse({ success: false, error: error.toString() });
    });
    return true; // Indicates asynchronous response
  }
});

// Open index.html when the extension icon is clicked
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});