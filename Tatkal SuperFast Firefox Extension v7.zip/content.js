

chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1],         // remove any existing rule with ID=1
    addRules: [{
      id: 1,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "Referer", operation: "set", value: "https://www.wps.irctc.co.in/" }
        ]
      },
      condition: {
        urlFilter: "https://www.irctcipay.com/pgui/jsp/surchargelocale?request_localeA=&defaultLanguageA=",
        resourceTypes: ["main_frame", "xmlhttprequest"]
      }
    }]
  });
});


chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [2],
    addRules: [{
      id: 2,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "Origin", operation: "set", value: "https://www.irctcipay.com" },
          { header: "Referer", operation: "set", value: "https://www.irctcipay.com/pgui/jsp/surchargePaymentPage.jsp" }
        ]
      },
      condition: {
        urlFilter: "https://www.irctcipay.com/pgui/jsp/otmPay",
        resourceTypes: ["main_frame", "xmlhttprequest"]
      }
    }]
  });
});


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "fetchTrainData") {
    fetch("https://www.indianrail.gov.in/enquiry/FetchTrainData", {
      method: "GET",
      headers: {
        "Connection": "close",
        "sec-ch-ua-platform": "\"macOS\"",
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "Accept": "*/*",
        "sec-ch-ua": "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
        "DNT": "1",
        "sec-ch-ua-mobile": "?0",
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
        "Accept-Encoding": "gzip, deflate, br",
        "Accept-Language": "en-US,en;q=0.9"
      }
    })
    .then(response => response.json())
    .then(data => {
      // Process the data to split each item into number and name.
      const processedData = data.map(item => {
        const parts = item.split(" - ");
        return {
          number: parts[0].trim(),
          name: parts[1] ? parts[1].trim() : ""
        };
      });
      sendResponse({ success: true, data: processedData });
    })
    .catch(error => {
      console.error("Error fetching train data:", error);
      sendResponse({ success: false, error: error.toString() });
    });
    return true; // Return true to indicate you wish to send a response asynchronously.
  }
});



chrome.browserAction.onClicked.addListener(() => {
    chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});
